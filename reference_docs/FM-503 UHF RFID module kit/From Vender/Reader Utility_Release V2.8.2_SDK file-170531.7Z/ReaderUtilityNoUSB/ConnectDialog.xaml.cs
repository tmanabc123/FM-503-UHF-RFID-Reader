﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO.Ports;
using System.Collections.ObjectModel;
using System.Threading;
using System.Windows.Threading;
using FAVEPC;

namespace ReaderUtility
{
	/// <summary>
	/// Interaction logic for ConnectDialog.xaml
	/// </summary>
	public partial class ConnectDialog : Window
	{
		private ReaderService	ReaderService;
		private Thread			SearchThread;
        private Int32           IBaudRate = 38400;
        //private ReaderService.Module.BaudRate mBaudRate = ReaderService.Module.BaudRate.B38400;


        public ConnectDialog() {
			InitializeComponent();

			//this.ButtonConnect.IsEnabled = false;
			this.ButtonEnter.IsEnabled = false;
			//this.ComboBoxReader.IsEnabled = false;
			//this.ComboBoxReader.Focusable = false;
            //this.ComboBoxBaudRate.IsEnabled = false;
            //this.ComboBoxBaudRate.Focusable = false;

            this.SearchThread = new Thread(DoSearchWork);
			this.SearchThread.IsBackground = true;
			this.SearchThread.Start();
		}

        public ConnectDialog(ReaderService.Module.BaudRate br)
        {
            InitializeComponent();

            //this.ButtonConnect.IsEnabled = false;
            this.ButtonEnter.IsEnabled = false;
            //this.ComboBoxReader.IsEnabled = false;
            //this.ComboBoxReader.Focusable = false;
            //this.ComboBoxBaudRate.IsEnabled = false;
            //this.ComboBoxBaudRate.Focusable = false;
            switch (br)
            {
                case ReaderService.Module.BaudRate.B4800: this.ComboBoxBaudRate.SelectedIndex = 0; break;
                case ReaderService.Module.BaudRate.B9600: this.ComboBoxBaudRate.SelectedIndex = 1; break;
                case ReaderService.Module.BaudRate.B14400: this.ComboBoxBaudRate.SelectedIndex = 2; break;
                case ReaderService.Module.BaudRate.B19200: this.ComboBoxBaudRate.SelectedIndex = 3; break;
                case ReaderService.Module.BaudRate.B38400: this.ComboBoxBaudRate.SelectedIndex = 4; break;
                case ReaderService.Module.BaudRate.B57600: this.ComboBoxBaudRate.SelectedIndex = 5; break;
                case ReaderService.Module.BaudRate.B115200: this.ComboBoxBaudRate.SelectedIndex = 6; break;
                case ReaderService.Module.BaudRate.B230400: this.ComboBoxBaudRate.SelectedIndex = 7; break;
            }

            this.SearchThread = new Thread(DoSearchWork);
            this.SearchThread.IsBackground = true;
            this.SearchThread.Start();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
		public ReaderService GetService() { return this.ReaderService; }

        /// <summary>
        /// Add baudrate parameter and modify process (2017/4/20)
        /// </summary>
		private void DoSearchWork() {
            ObservableCollection<string> oc = new ObservableCollection<string>();

            foreach (ReaderService.Reader rs in ReaderService.GetReaders())
            {
                if (rs != null)
                    oc.Add(string.Format("{0} –{1}", rs.Name, rs.Description));
            }

            Dispatcher.Invoke(DispatcherPriority.Normal, new Action<ObservableCollection<string>>(CollectionData), oc);
			Thread.Sleep(100);
		}

        /// <summary>
        /// 
        /// </summary>
		private void DoConnectWork() {

			try {
                Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                    String[] words = (ComboBoxReader.SelectedItem as string).Split(' ');
                    IBaudRate = Int32.Parse(((ComboBoxItem)ComboBoxBaudRate.SelectedItem).Content.ToString());


                    this.ReaderService = new ReaderService();
                    this.ReaderService.Open(words[0], IBaudRate, (Parity)Enum.Parse(typeof(Parity), "None", true), 8, (StopBits)Enum.Parse(typeof(StopBits), "One", true));

                    if (this.ReaderService.IsOpen())
                    {
                        this.ReaderService.Send(this.ReaderService.Command_V());
                        byte[] b = this.ReaderService.Receive(100);
                        if (b != null)
                        {
                            string s = ReaderService.Format.RemoveCRLF(ReaderService.Format.BytesToString(b));
                            if (s.Contains("V"))
                            {
                                ShowOnTBMSG2(String.Format("{0}已連接並驗證", words[0]));
                                this.ButtonEnter.IsEnabled = true;
                                this.ButtonConnect.IsEnabled = false;
                            }       
                            else
                            {
                                ShowOnTBMSG2("開啟" + words[0] + "失敗，並非是Reader模組");
                                this.ReaderService.Close();
                                this.ReaderService = null;
                                ButtonConnect.IsEnabled = true;
                            }
                        }
                        else
                        {
                            ShowOnTBMSG2("開啟" + words[0] + "失敗，驗證未回覆。");
                            this.ReaderService.Close();
                            this.ReaderService = null;
                            ButtonConnect.IsEnabled = true;
                        }
                    }
                    else
                    {
                        ShowOnTBMSG2("開啟" + words[0] + "失敗.");
                        this.ReaderService.Close();
                        this.ReaderService = null;
                        ButtonConnect.IsEnabled = true;
                    }

                    
                    new Thread(DisableMsg).Start();
                }));
			}
			catch (Exception ex) {
                Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                    ShowOnTBMSG1("嘗試連接失敗");
                    ShowOnTBMSG2(ex.Message);
                    this.ReaderService.Close();
                    this.ReaderService = null;
                }));
            }
		}

        private void DisableMsg()
        {
            Thread.Sleep(2000);
            Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                ShowOnTBMSG1("");
                ShowOnTBMSG2("");
            }));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
		private void ShowOnTBMSG1(String str) { this.TBMSG1.Text = str; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
		private void ShowOnTBMSG2(String str) { this.TBMSG2.Text = str; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="s"></param>
		private void CollectionData(ObservableCollection<String> s) {
			this.ComboBoxReader.ItemsSource = s;
			this.ComboBoxReader.SelectedIndex = 0;
        }

        /// <summary>
        /// When combobox dropdown is opened which to search COM device
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnComboboxReaderDropDownOpened(object sender, EventArgs e) {
            ObservableCollection<string> oc = new ObservableCollection<string>();
            IBaudRate = Int32.Parse(((ComboBoxItem)ComboBoxBaudRate.SelectedItem).Content.ToString());

            foreach (ReaderService.Reader rs in ReaderService.GetReaders())
            {
                if (rs != null)
                    oc.Add(string.Format("{0} –{1}", rs.Name, rs.Description));
            }

            if (oc.Count > 0)
                CollectionData(oc);
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonConnectClick(object sender, RoutedEventArgs e)
        {
            ButtonConnect.IsEnabled = false;
            ShowOnTBMSG1("");
            ShowOnTBMSG2("");
            this.SearchThread = new Thread(DoConnectWork);
			this.SearchThread.IsBackground = true;
			this.SearchThread.Start();
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonEnterClick(object sender, RoutedEventArgs e) {
			this.DialogResult = true;
		}

        /// <summary>
        /// Close the utility
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnConnectDialogCloseClick(object sender, RoutedEventArgs e)
        {
			this.DialogResult = false;
			if (this.ReaderService != null && this.ReaderService.IsOpen())
				this.ReaderService.Close();
			this.Close();
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnConnectBorderMouseLeftDown(object sender, MouseButtonEventArgs e)
        {
			this.DragMove();
		}

        
		
	}
}
