﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Threading;
using System.Globalization;
using FAVEPC;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.ComponentModel;
using System.IO.Ports;

namespace ReaderUtility
{
	public partial class RegulationDialog : Window {

		private const int PROC_READ_REGULATION			= 0x01;
		private const int PROC_READ_MODE_AND_CHANNEL	= 0x02;
		private const int PROC_READ_FREQ_OFFSET			= 0x03;
		private const int PROC_READ_POWER				= 0x04;
		private const int PROC_READ_FREQ				= 0x06;
		private const int PROC_SET_FREQ_H				= 0x07;
		private const int PROC_SET_FREQ_L				= 0x08;
		private const int PROC_SET_FREQ					= 0x09;
		private const int PROC_SET_MEASURE_FREQ			= 0X0A;
		private const int PROC_SET_RESET				= 0x0B;
		private const int PROC_FREQ_SET_RESET			= 0x0C;
        private const int PROC_READ_GPIO_CONFIG         = 0x0D;
        private const int PROC_READ_GPIO_PINS           = 0x0E;
        private const int PROC_REBOOT					= 0xFF;

		private readonly DispatcherTimer		RepeatEvent = new DispatcherTimer();
		private readonly DispatcherTimer		ProcessEvent = new DispatcherTimer();
		private Byte[]							ReceiveData;
		private Int32                           PreProcess;
		
		private Boolean							IsSymbol = false;
		private Boolean                         IsAdjust = false, 
												IsPlus = false, 
												IsMinus = false, 
												IsReset = false;
		private Boolean                         IsRunning = false;
		private Boolean                         IsReceiveData = false;
		private Boolean                         IsDateTimeStamp = false;
		private Boolean                         IsSetFrequency = false;
		private ReaderService					_ReaderService = null;
		private ReaderService.Module.Version	_Version;
        private ReaderService.Module.BaudRate   _BaudRate = ReaderService.Module.BaudRate.B38400;

        private Int32                           IRegulation = 8;
        private CultureInfo						Culture;
		private Int32                           BasebandMode;


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ReaderService.Module.BaudRate GetBaudRate()
        {
            return _BaudRate;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public ReaderService GetService()
        {
            return this._ReaderService;
        }


        public RegulationDialog(ReaderService service, ReaderService.Module.Version v, ReaderService.Module.BaudRate br, CultureInfo selected_culture) {
			InitializeComponent();

            this._ReaderService = service;
			this._Version = v;
            this._BaudRate = br;
            switch (this._BaudRate)
            {
                case ReaderService.Module.BaudRate.B4800: this.ComboBoxBaudRate.SelectedIndex = 0; break;
                case ReaderService.Module.BaudRate.B9600: this.ComboBoxBaudRate.SelectedIndex = 1; break;
                case ReaderService.Module.BaudRate.B14400: this.ComboBoxBaudRate.SelectedIndex = 2; break;
                case ReaderService.Module.BaudRate.B19200: this.ComboBoxBaudRate.SelectedIndex = 3; break;
                case ReaderService.Module.BaudRate.B38400: this.ComboBoxBaudRate.SelectedIndex = 4; break;
                case ReaderService.Module.BaudRate.B57600: this.ComboBoxBaudRate.SelectedIndex = 5; break;
                case ReaderService.Module.BaudRate.B115200: this.ComboBoxBaudRate.SelectedIndex = 6; break;
                case ReaderService.Module.BaudRate.B230400: this.ComboBoxBaudRate.SelectedIndex = 7; break;
            }
            this.Culture = selected_culture;


            UICtrlModify(this._Version);
            AreaModify(this._Version);
            PowerModify(this._Version);
			FrequencyStepModify();

			this._ReaderService.CombineDataReceiveEvent += new ReaderService.CombineDataHandler(DoReceiveDataWork);
		}


        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="v"></param>
        private void UICtrlModify(ReaderService.Module.Version v)
        {
            switch (this._Version)
            {
                case ReaderService.Module.Version.FI_R3008:
                case ReaderService.Module.Version.FI_RXXXX:
                    UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
                    "The Reader version is not support the advanced setting." :
                    "此版本Reader不支援此進階操作", false);
                    break;
                case ReaderService.Module.Version.FI_R300A_C1:
                case ReaderService.Module.Version.FI_R300A_C2:
                case ReaderService.Module.Version.FI_R300T_D1:
                case ReaderService.Module.Version.FI_R300T_D2:
                case ReaderService.Module.Version.FI_A300S:
                    this.GroupBaudRate.IsEnabled = false;
                    this.GroupGPIO.IsEnabled = false; 
                    EventInit();
                    break;
                case ReaderService.Module.Version.FI_R300A_C2C4:
                case ReaderService.Module.Version.FI_R300T_D204:
                    this.GroupBaudRate.IsEnabled = false;
                    EventInit();
                    break;
                case ReaderService.Module.Version.FI_R300A_C3:
                case ReaderService.Module.Version.FI_R300S:
                    EventInit();

                    break;
            }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="v"></param>
        private void PowerModify(ReaderService.Module.Version v)
        {
            ObservableCollection<string> list = new ObservableCollection<string>();
            switch (v)
            {
                case ReaderService.Module.Version.FI_R300T_D1:
                case ReaderService.Module.Version.FI_R300T_D2:
                case ReaderService.Module.Version.FI_R300T_D204:
                    foreach (ReaderService.Module.PowerItem power in ReaderService.Module.GetPowerGroups(ReaderService.Module.Version.FI_R300T_D1))
                        list.Add(string.Format("{0}", power.LocationName));
                    break;
                case ReaderService.Module.Version.FI_R300A_C1:
                case ReaderService.Module.Version.FI_R300A_C2:
                case ReaderService.Module.Version.FI_R300A_C2C4:
                case ReaderService.Module.Version.FI_R300A_C3:
                    foreach (ReaderService.Module.PowerItem power in ReaderService.Module.GetPowerGroups(ReaderService.Module.Version.FI_R300A_C1))
                        list.Add(string.Format("{0}", power.LocationName));
                    break;
                case ReaderService.Module.Version.FI_R300S:
                case ReaderService.Module.Version.FI_A300S:
                    foreach (ReaderService.Module.PowerItem power in ReaderService.Module.GetPowerGroups(ReaderService.Module.Version.FI_A300S))
                        list.Add(string.Format("{0}", power.LocationName));
                    break;
                case ReaderService.Module.Version.FI_RXXXX:
                    list.Add("== N/A ==");
                    break;
            }

            this.ComboboxPower.ItemsSource = list;
            this.ComboboxPower.SelectedIndex = 0;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="v"></param>
        private void AreaModify(ReaderService.Module.Version v)
        {
            ObservableCollection<string> list = new ObservableCollection<string>();
            switch (v)
            {
                case ReaderService.Module.Version.FI_R300T_D1:
                case ReaderService.Module.Version.FI_R300T_D2:
                case ReaderService.Module.Version.FI_R300A_C1:
                case ReaderService.Module.Version.FI_R300A_C2:
                case ReaderService.Module.Version.FI_A300S:
                case ReaderService.Module.Version.FI_RXXXX:
                    foreach (ReaderService.Module.AreaItem area in ReaderService.Module.GetAreaGroups(ReaderService.Module.Version.FI_R300T_D1))
                        list.Add(string.Format("{0}", area.LocationName));
                    break;
                case ReaderService.Module.Version.FI_R300A_C2C4:
                case ReaderService.Module.Version.FI_R300T_D204:
                case ReaderService.Module.Version.FI_R300S:
                case ReaderService.Module.Version.FI_R300A_C3:
                    foreach (ReaderService.Module.AreaItem area in ReaderService.Module.GetAreaGroups(ReaderService.Module.Version.FI_R300A_C3))
                        list.Add(string.Format("{0}", area.LocationName));
                    break;
            }

            this.ComboBoxArea.ItemsSource = list;
            //this.ComboBoxArea.SelectedIndex = 0;
        }

        /// <summary>
        /// 
        /// </summary>
		private void FrequencyStepModify()
        {
            ObservableCollection<string> list = new ObservableCollection<string>();
            foreach (string s in DataRepository.GetStepGroups()) list.Add(s);
            this.ComboboxStep.ItemsSource = list;
            this.ComboboxStep.SelectedIndex = 0;
        }

        /// <summary>
        /// 
        /// </summary>
        private void EventInit()
        {
            this.RepeatEvent.Tick += new EventHandler(DoRepeatWork);
            this.RepeatEvent.Interval = TimeSpan.FromMilliseconds(64);
            this.ProcessEvent.Tick += new EventHandler(DoPreProcessWork);
            this.ProcessEvent.Interval = TimeSpan.FromMilliseconds(64);
            this.PreProcess = PROC_READ_REGULATION;
            this.ProcessEvent.Start();
            UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
                "Get the Reader information." :
                "取得Reader資訊..", false);
        }





        #region === Group Setting ===
        /// <summary>
        ///  Modify use J000(reset) to set frequency (2017/4/18)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnButtonSetAreaClick(object sender, RoutedEventArgs e)
        {
            if (ComboBoxFrequency != null && ComboBoxMeasureFrequency != null)
            {

                //J000(reset) to set frequency
                IsSetFrequency = true;
                DoSendWork(this._ReaderService.Command_J("0", "00"), ReaderService.Module.CommandType.Normal);
                DoReceiveWork(ReaderService.Module.CommandType.Normal);

                ReaderService.Module.Regulation _regulation = ReaderService.Module.Regulation.US;
                switch (this.ComboBoxArea.SelectedIndex)
                {
                    case 0:
                        _regulation = ReaderService.Module.Regulation.US;
                        DoSendWork(this._ReaderService.SetRegulation(ReaderService.Module.Regulation.US), ReaderService.Module.CommandType.Normal);
                        break;
                    case 1:
                        _regulation = ReaderService.Module.Regulation.TW;
                        DoSendWork(this._ReaderService.SetRegulation(ReaderService.Module.Regulation.TW), ReaderService.Module.CommandType.Normal);
                        break;
                    case 2:
                        _regulation = ReaderService.Module.Regulation.CN;
                        DoSendWork(this._ReaderService.SetRegulation(ReaderService.Module.Regulation.CN), ReaderService.Module.CommandType.Normal);
                        break;
                    case 3:
                        _regulation = ReaderService.Module.Regulation.CN2;
                        DoSendWork(this._ReaderService.SetRegulation(ReaderService.Module.Regulation.CN2), ReaderService.Module.CommandType.Normal);
                        break;
                    case 4:
                        _regulation = ReaderService.Module.Regulation.EU;
                        DoSendWork(this._ReaderService.SetRegulation(ReaderService.Module.Regulation.EU), ReaderService.Module.CommandType.Normal);
                        break;
                    case 5:
                        _regulation = ReaderService.Module.Regulation.JP;
                        DoSendWork(this._ReaderService.SetRegulation(ReaderService.Module.Regulation.JP), ReaderService.Module.CommandType.Normal);
                        break;
                    case 6:
                        _regulation = ReaderService.Module.Regulation.KR;
                        DoSendWork(this._ReaderService.SetRegulation(ReaderService.Module.Regulation.KR), ReaderService.Module.CommandType.Normal);
                        break;
                    case 7:
                        _regulation = ReaderService.Module.Regulation.VN;
                        DoSendWork(this._ReaderService.SetRegulation(ReaderService.Module.Regulation.VN), ReaderService.Module.CommandType.Normal);
                        break;
                }
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (this.ReceiveData != null && this.ReceiveData.Length == 6)
                {
                    string str = Encoding.ASCII.GetString(new byte[] { ReceiveData[2], ReceiveData[3] });
                    System.Reflection.FieldInfo fi = _regulation.GetType().GetField(_regulation.ToString());
                    if (fi != null)
                    {
                        object[] attrs = fi.GetCustomAttributes(typeof(DescriptionAttribute), true);
                        if (attrs != null && attrs.Length > 0)
                        {
                            string dbr = ((DescriptionAttribute)attrs[0]).Description;
                            if (dbr.Equals(str))
                            {
                                this.LabelMessage.Text = (this.Culture.IetfLanguageTag == "en-US") ? "Set area success" : "設定area成功";
                                if (ComboBoxFrequency != null && ComboBoxMeasureFrequency != null)
                                {
                                    ComboBoxSetAreaChanged(this.ComboBoxArea.SelectedIndex);
                                    this.IRegulation = this.ComboBoxArea.SelectedIndex + 1;
                                }
                            }
                        }
                    }
                }
                else
                {
                    this.LabelMessage.Text = (this.Culture.IetfLanguageTag == "en-US") ? "Set area no reply or error" : "設定area未回覆或錯誤";
                }
            }
        }

        /// <summary>
        /// Modify ComboBoxMeasureFrequency.SelectedIndex = hopping & radiobutton to BasebandCarryMode (2017/4/18)
        /// </summary>
        /// <param name="index"></param>
        private void ComboBoxSetAreaChanged(int index) {
			ObservableCollection<string> items = new ObservableCollection<string>();

            //radiobutton reset to BasebandCarryMode
            BasebandCarryMode.IsChecked = true;

            switch (index) {
				case 0:
					for (int i = 0; i < ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.US); i++) {
						double j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.US, i);
						items.Add(string.Format("{0}MHz", j.ToString("###.00")));
					}
					items.Add("hopping");
                    
                    ComboBoxFrequency.ItemsSource = items;
                    ComboBoxFrequency.SelectedIndex = ReaderService.Module.RegulationMidChannel(ReaderService.Module.Regulation.US);
                    ComboBoxMeasureFrequency.ItemsSource = items; 
                    ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.US);
					break;
				case 1:
					for (int i = 0; i < ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.TW); i++) {
						double j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.TW, i);
                        items.Add(string.Format("{0}MHz", j.ToString("###.00")));
					}
					items.Add("hopping");

					ComboBoxFrequency.ItemsSource = items;
                    ComboBoxFrequency.SelectedIndex = ReaderService.Module.RegulationMidChannel(ReaderService.Module.Regulation.TW);
                    ComboBoxMeasureFrequency.ItemsSource = items;
                    ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.TW);
                    break;
				case 2:
					for (int i = 0; i < ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.CN); i++) {
						double j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.CN, i);
                        items.Add(string.Format("{0}MHz", j.ToString("###.000")));
					}
					items.Add("hopping");

					ComboBoxFrequency.ItemsSource = items;
                    ComboBoxFrequency.SelectedIndex = ReaderService.Module.RegulationMidChannel(ReaderService.Module.Regulation.CN);
                    ComboBoxMeasureFrequency.ItemsSource = items;
                    ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.CN);
                    break;
				case 3:
					for (int i = 0; i < ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.CN2); i++) {
						double j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.CN2, i);
                        items.Add(string.Format("{0}MHz", j.ToString("###.000")));
					}
					items.Add("hopping");

					ComboBoxFrequency.ItemsSource = items;
                    ComboBoxFrequency.SelectedIndex = ReaderService.Module.RegulationMidChannel(ReaderService.Module.Regulation.CN2);
                    ComboBoxMeasureFrequency.ItemsSource = items;
                    ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.CN2);
                    break;
				case 4:
					for (int i = 0; i < ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.EU); i++) {
						double j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.EU, i);
                        items.Add(string.Format("{0}MHz", j.ToString("###.00")));
					}
					items.Add("hopping");

					ComboBoxFrequency.ItemsSource = items;
                    ComboBoxFrequency.SelectedIndex = ReaderService.Module.RegulationMidChannel(ReaderService.Module.Regulation.EU);
                    ComboBoxMeasureFrequency.ItemsSource = items;
                    ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.EU);
                    break;
                case 5:
                    for (int i = 0; i < ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.JP); i++)
                    {
                        double j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.JP, i);
                        items.Add(string.Format("{0}MHz", j.ToString("###.00")));
                    }
                    items.Add("hopping");

                    ComboBoxFrequency.ItemsSource = items;
                    ComboBoxFrequency.SelectedIndex = ReaderService.Module.RegulationMidChannel(ReaderService.Module.Regulation.JP);
                    ComboBoxMeasureFrequency.ItemsSource = items;
                    ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.JP);
                    break;
                case 6:
                    for (int i = 0; i < ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.KR); i++)
                    {
                        double j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.KR, i);
                        items.Add(string.Format("{0}MHz", j.ToString("###.00")));
                    }
                    items.Add("hopping");

                    ComboBoxFrequency.ItemsSource = items;
                    ComboBoxFrequency.SelectedIndex = ReaderService.Module.RegulationMidChannel(ReaderService.Module.Regulation.KR);
                    ComboBoxMeasureFrequency.ItemsSource = items;
                    ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.KR);
                    break;
                case 7:
                    for (int i = 0; i < ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.VN); i++)
                    {
                        double j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.VN, i);
                        items.Add(string.Format("{0}MHz", j.ToString("###.00")));
                    }
                    items.Add("hopping");

                    ComboBoxFrequency.ItemsSource = items;
                    ComboBoxFrequency.SelectedIndex = ReaderService.Module.RegulationMidChannel(ReaderService.Module.Regulation.VN);
                    ComboBoxMeasureFrequency.ItemsSource = items; 
                    ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.VN);
                    break;
            }
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonSetFrequencyClick(object sender, RoutedEventArgs e) {
			int idx = this.ComboBoxFrequency.SelectedIndex + 1;
			string str = ReaderService.Format.ByteToHexString((byte)idx);
			DoSendWork(this._ReaderService.Command_J("1", str), ReaderService.Module.CommandType.Normal);
			DoReceiveWork(ReaderService.Module.CommandType.Normal);
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonAdjustClick(object sender, RoutedEventArgs e) {
			if (TextBoxMeasureFrequency.GetLineText(0) != "") {
				this.IsAdjust = true;
				this.PreProcess = PROC_READ_FREQ;
				this.ProcessEvent.Start();
				UIUnitControl("", false);
			}
			else {
				UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
							"Enter the measurement frequency.." :
							"請輸入量測頻率", true);
				FocusManager.SetFocusedElement(this, this.TextBoxMeasureFrequency);
			}
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonSetFrequencyPlusClick(object sender, RoutedEventArgs e) {
			this.IsPlus = true;
			this.PreProcess = PROC_READ_FREQ;
			this.ProcessEvent.Start();
			UIUnitControl("", false);
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonSetFrequencyMinusClick(object sender, RoutedEventArgs e) {
			this.IsMinus = true;
			this.PreProcess = PROC_READ_FREQ;
			this.ProcessEvent.Start();
			UIUnitControl("", false);
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonSetFrequencyResetClick(object sender, RoutedEventArgs e) {
			this.IsReset = true;
			this.PreProcess = PROC_FREQ_SET_RESET;
			this.ProcessEvent.Start();
			UIUnitControl("", false);
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnComboboxPowerSelectionChanged(object sender, SelectionChangedEventArgs e) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnButtonSetPowerClick(object sender, RoutedEventArgs e) {
			int idx = ReaderService.Module.GetPowerGroupsIndex(this._Version, ComboboxPower.SelectedIndex);

			DoSendWork(this._ReaderService.SetPower(ReaderService.Format.ByteToHexString((byte)idx)), ReaderService.Module.CommandType.Normal);
			DoReceiveWork(ReaderService.Module.CommandType.Normal);
		}
        #endregion



        #region === Group Measure ===

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnRadioButtonBasebandModeChecked(object sender, RoutedEventArgs e) {
			var radioButton = sender as RadioButton;
			if (radioButton == null) return;
			this.BasebandMode = Convert.ToInt32(radioButton.Tag.ToString());
		}
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonMeasureSetFrequencyClick(object sender, RoutedEventArgs e) {
			byte[] bs = null;
			int idx = ComboBoxMeasureFrequency.SelectedIndex + 1;

			switch (ComboBoxArea.SelectedIndex) {
				case 0:
					if (idx == ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.US) + 1)
                        bs = this._ReaderService.Command_J("0", "00");
					break;
				case 1:
                case 7:
					if (idx == ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.TW) + 1)
                        bs = this._ReaderService.Command_J("0", "00");
					break;
				case 2:
				case 3:
					if (idx == ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.CN) + 1)
                        bs = this._ReaderService.Command_J("0", "00");
					break;
				
				case 4:
                case 5:
                    if (idx == ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.EU) + 1)
                        bs = this._ReaderService.Command_J("0", "00");
					break;
                case 6:
                    if (idx == ReaderService.Module.RegulationChannel(ReaderService.Module.Regulation.KR) + 1)
                        bs = this._ReaderService.Command_J("0", "00");
                    break;
            }

			if (bs == null) {
				bs = this._ReaderService.Command_J((this.BasebandMode == 2) ? "2" : "1", ReaderService.Format.ByteToHexString((byte)idx));
			}
			IsSetFrequency = true;
			DoSendWork(bs, ReaderService.Module.CommandType.Normal);
			DoReceiveWork(ReaderService.Module.CommandType.Normal);
		}
  
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnButtonMeasureRunClick(object sender, RoutedEventArgs e) {
			if (!IsSetFrequency) {
				UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Run set frequency first.." : "請先設定頻率..", true);
				ButtonMeasureSetFrequency.Focus();
				return;
			}
			if (!this.IsRunning) {
				this.IsRunning = true;
				this.ButtonMeasureRun.Content = (this.Culture.IetfLanguageTag == "en-US") ? "Stop" : "停止";
				this.RepeatEvent.Start();
				UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Running Tag test.." : "正在執行Tag測試..", false);
			}
			else {
				this.IsRunning = false;
				this.ButtonMeasureRun.Content = (this.Culture.IetfLanguageTag == "en-US") ? "Run" : "執行";
			}

		}

        #endregion


        #region === Group Baudrate ===
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnButtonSetBuadRateClick(object sender, RoutedEventArgs e)
        {
            ReaderService.Module.BaudRate br = ReaderService.Module.BaudRate.B4800;
            switch (this.ComboBoxBaudRate.SelectedIndex)
            {
                case 0: br = ReaderService.Module.BaudRate.B4800; break;
                case 1: br = ReaderService.Module.BaudRate.B9600; break;
                case 2: br = ReaderService.Module.BaudRate.B14400; break;
                case 3: br = ReaderService.Module.BaudRate.B19200; break;
                case 4: br = ReaderService.Module.BaudRate.B38400; break;
                case 5: br = ReaderService.Module.BaudRate.B57600; break;
                case 6: br = ReaderService.Module.BaudRate.B115200; break;
                case 7: br = ReaderService.Module.BaudRate.B230400; break;
            }
            DoSendWork(this._ReaderService.SetBaudRate(br), ReaderService.Module.CommandType.Normal);
            this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
            if (this.ReceiveData.Length == 6)
            {
                //byte[] b = new byte[] { ReceiveData[2], ReceiveData[3] };
                string str = Encoding.ASCII.GetString(new byte[] { ReceiveData[2], ReceiveData[3] });
                System.Reflection.FieldInfo fi = _BaudRate.GetType().GetField(_BaudRate.ToString());
                if (fi != null)
                {
                    object[] attrs = fi.GetCustomAttributes(typeof(DescriptionAttribute), true);
                    if (attrs != null && attrs.Length > 0)
                    {
                        string dbr = ((DescriptionAttribute)attrs[0]).Description;
                        if (!dbr.Equals(str))
                        {
                            //reconnect
                            UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Baud rate changed and reconnect module.." : "Baud rate改變，重新連線中..", false);
                            string port = this._ReaderService.GetSerialPort().PortName;
                            int ibr = this._ReaderService.GetBaudRate(str);
                            this._ReaderService.Close();
                            this._ReaderService = null;
                            Thread.Sleep(100);
                            this._ReaderService = new ReaderService();
                            this._ReaderService.Open(port, ibr, (Parity)Enum.Parse(typeof(Parity), "None", true), 8, (StopBits)Enum.Parse(typeof(StopBits), "One", true));

                            if (this._ReaderService.IsOpen())
                            {
                                UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? String.Format("Utility has reconnected to module, and change baud rate to {0}", ibr) : String.Format("已重新連線, baud rate設定至{0}", ibr), true);
                                _BaudRate = this._ReaderService.GetBaudRate(ibr);
                            }
                            else
                                UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "reconnect error" : "連線失敗", false);
                        }
                    }
                }

            }
        }
        #endregion



        #region === Group GPIO ===
        private int GPIOConfigurMask = 0;
        private void OnCheckedGPIOConfigur10(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOConfiguration10)
            {
                DoSendWork(this._ReaderService.SetGPIOConfiguration("44"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOConfigur.SelectedIndex = val;
                }
            }
            IsGetGPIOConfiguration10 = false;
            GPIOConfigurMask |= 0x04;
        }

        private void OnUncheckedGPIOConfigur10(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOConfiguration10)
            {
                DoSendWork(this._ReaderService.SetGPIOConfiguration("40"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOConfigur.SelectedIndex = val;
                }
            }
            IsGetGPIOConfiguration10 = false;
            GPIOConfigurMask &= 0xFB;
        }

        private void OnCheckedGPIOConfigur11(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOConfiguration11)
            {
                DoSendWork(this._ReaderService.SetGPIOConfiguration("22"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOConfigur.SelectedIndex = val;
                }
            }
            IsGetGPIOConfiguration11 = false;
            GPIOConfigurMask |= 0x02;
        }

        private void OnUncheckedGPIOConfigur11(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOConfiguration11)
            {
                DoSendWork(this._ReaderService.SetGPIOConfiguration("20"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOConfigur.SelectedIndex = val;
                }
            }
            IsGetGPIOConfiguration11 = false;
            GPIOConfigurMask &= 0xFD;
        }

        private void OnCheckedGPIOConfigur14(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOConfiguration14)
            {
                DoSendWork(this._ReaderService.SetGPIOConfiguration("11"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOConfigur.SelectedIndex = val;
                }
            }
            IsGetGPIOConfiguration14 = false;
            GPIOConfigurMask |= 0x01;
        }

        private void OnUncheckedGPIOConfigur14(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOConfiguration14)
            {
                DoSendWork(this._ReaderService.SetGPIOConfiguration("10"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOConfigur.SelectedIndex = val;
                }
            }
            IsGetGPIOConfiguration14 = false;
            GPIOConfigurMask &= 0xFE;
        }



        private void OnCheckedGPIOPins10(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOPin10)
            {
                DoSendWork(this._ReaderService.SetGPIOPins("44"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOPins.SelectedIndex = val;
                }
            }
            IsGetGPIOPin10 = false;
        }

        private void OnUncheckedGPIOPins10(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOPin10)
            {
                DoSendWork(this._ReaderService.SetGPIOPins("40"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOPins.SelectedIndex = val;
                }
            }
            IsGetGPIOPin10 = false;
        }

        private void OnCheckedGPIOPins11(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOPin11)
            {
                DoSendWork(this._ReaderService.SetGPIOPins("22"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOPins.SelectedIndex = val;
                }
            }
            IsGetGPIOPin11 = false;
        }

        private void OnUncheckedGPIOPins11(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOPin11)
            {
                DoSendWork(this._ReaderService.SetGPIOPins("20"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOPins.SelectedIndex = val;
                }
            }
            IsGetGPIOPin11 = false;
        }

        private void OnCheckedGPIOPins14(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOPin14)
            {
                DoSendWork(this._ReaderService.SetGPIOPins("11"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOPins.SelectedIndex = val;
                }
            }
            IsGetGPIOPin14 = false;
        }

        private void OnUncheckedGPIOPins14(object sender, RoutedEventArgs e)
        {
            if (!IsGetGPIOPin14)
            {
                DoSendWork(this._ReaderService.SetGPIOPins("10"), ReaderService.Module.CommandType.Normal);
                this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
                if (ReceiveData.Length == 5)
                {
                    int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                    ComboBoxGPIOPins.SelectedIndex = val;
                }
            }
            IsGetGPIOPin14 = false;
        }

        private bool IsGetGPIOConfiguration10 = false;
        private bool IsGetGPIOConfiguration11 = false;
        private bool IsGetGPIOConfiguration14 = false;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnButtonGetGPIOConfigurationClick(object sender, RoutedEventArgs e)
        {
            DoSendWork(this._ReaderService.GetGPIOConfiguration(), ReaderService.Module.CommandType.Normal);
            this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);

            if (ReceiveData.Length == 5)
            {
                int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                int mask = GPIOConfigurMask;
                if (mask != val)
                {
                    if (((val ^ mask) & 0x04) == 0x04)
                    {
                        IsGetGPIOConfiguration10 = true;
                        if ((val & (byte)0x04) > 0) CheckBoxGPIOConfigur10.IsChecked = true;
                        else CheckBoxGPIOConfigur10.IsChecked = false;
                    }

                    if (((val ^ mask) & 0x02) == 0x02)
                    {
                        IsGetGPIOConfiguration11 = true;
                        if ((val & (byte)0x02) > 0) CheckBoxGPIOConfigur11.IsChecked = true;
                        else CheckBoxGPIOConfigur11.IsChecked = false;
                    }

                    if (((val ^ mask) & 0x01) == 0x01)
                    {
                        IsGetGPIOConfiguration14 = true;
                        if ((val & (byte)0x01) > 0) CheckBoxGPIOConfigur14.IsChecked = true;
                        else CheckBoxGPIOConfigur14.IsChecked = false;
                    }

                }
            }
        }


        private bool IsGetGPIOPin10 = false;
        private bool IsGetGPIOPin11 = false;
        private bool IsGetGPIOPin14 = false;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnButtonGetGPIOPortClick(object sender, RoutedEventArgs e)
        {
            DoSendWork(this._ReaderService.GetGPIOPins(), ReaderService.Module.CommandType.Normal);
            this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
            if (ReceiveData.Length == 5)
            {
                int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                if ((val & (byte)0x04) > 0)
                {
                    CheckBoxGPIOPin10Status.IsChecked = true;
                    /*if (!CheckBoxGPIOPin10.IsChecked.Value)
                    {
                        IsGetGPIOPin10 = true;
                        CheckBoxGPIOPin10.IsChecked = true;
                    }*/
                }
                else
                {
                    CheckBoxGPIOPin10Status.IsChecked = false;
                    /*if (CheckBoxGPIOPin10.IsChecked.Value)
                    {
                        IsGetGPIOPin10 = true;
                        CheckBoxGPIOPin10.IsChecked = false;
                    }*/
                }
                if ((val & (byte)0x02) > 0)
                {
                    CheckBoxGPIOPin11Status.IsChecked = true;
                    /*if (!CheckBoxGPIOPin11.IsChecked.Value)
                    {
                        IsGetGPIOPin11 = true;
                        CheckBoxGPIOPin11.IsChecked = true;
                    }*/
                }
                else
                {
                    CheckBoxGPIOPin11Status.IsChecked = false;
                    /*if (CheckBoxGPIOPin11.IsChecked.Value)
                    {
                        IsGetGPIOPin11 = true;
                        CheckBoxGPIOPin11.IsChecked = false;
                    }*/
                }
                if ((val & (byte)0x01) > 0)
                {
                    CheckBoxGPIOPin14Status.IsChecked = true;
                    /*if (!CheckBoxGPIOPin14.IsChecked.Value)
                    {
                        IsGetGPIOPin14 = true;
                        CheckBoxGPIOPin14.IsChecked = true;
                    }*/
                }
                else
                {
                    CheckBoxGPIOPin14Status.IsChecked = false;
                    /*if (CheckBoxGPIOPin14.IsChecked.Value)
                    {
                        IsGetGPIOPin14 = true;
                        CheckBoxGPIOPin14.IsChecked = false;
                    }*/
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnComboBoxSetGPIOConfigurDownClosed(object sender, EventArgs e)
        {
            string gval = ((ComboBoxItem)ComboBoxGPIOConfigur.SelectedItem).Tag as string;
            string str = "7" + gval;
            DoSendWork(this._ReaderService.SetGPIOConfiguration(str), ReaderService.Module.CommandType.Normal);
            ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);


            if (ReceiveData != null && ReceiveData.Length == 5)
            {
                int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));      
                int mask = GPIOConfigurMask;
                if (mask != val)
                {
                    if (((val ^ mask) & 0x04) == 0x04)
                    {
                        IsGetGPIOConfiguration10 = true;
                        if ((val & (byte)0x04) > 0) CheckBoxGPIOConfigur10.IsChecked = true;
                        else CheckBoxGPIOConfigur10.IsChecked = false;
                    }

                    if (((val ^ mask) & 0x02) == 0x02)
                    {
                        IsGetGPIOConfiguration11 = true;
                        if ((val & (byte)0x02) > 0) CheckBoxGPIOConfigur11.IsChecked = true;
                        else CheckBoxGPIOConfigur11.IsChecked = false;
                    }

                    if (((val ^ mask) & 0x01) == 0x01)
                    {
                        IsGetGPIOConfiguration14 = true;
                        if ((val & (byte)0x01) > 0) CheckBoxGPIOConfigur14.IsChecked = true;
                        else CheckBoxGPIOConfigur14.IsChecked = false;
                    }
                }
            }
            else
            {
                this.LabelMessage.Text = (this.Culture.IetfLanguageTag == "en-US") ? "Set GPIO configuration error" : "設定GPIO configuration失敗";
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnComboBoxSetGPIOPinsDownClosed(object sender, EventArgs e)
        {
            string gval = ((ComboBoxItem)ComboBoxGPIOPins.SelectedItem).Tag as string;
            string str = "7" + gval;

            DoSendWork(this._ReaderService.SetGPIOPins(str), ReaderService.Module.CommandType.Normal);
            ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);

            if (ReceiveData != null && ReceiveData.Length == 5)
            {
                int val = Int32.Parse(ReaderService.Format.ByteToString(ReceiveData[2]));
                if ((val & (byte)0x04) > 0)
                {
                    if (!CheckBoxGPIOPin10.IsChecked.Value)
                    {
                        IsGetGPIOPin10 = true;
                        CheckBoxGPIOPin10.IsChecked = true;
                    }
                }
                else
                {
                    if (CheckBoxGPIOPin10.IsChecked.Value)
                    {
                        IsGetGPIOPin10 = true;
                        CheckBoxGPIOPin10.IsChecked = false;
                    }
                }
                if ((val & (byte)0x02) > 0)
                {
                    if (!CheckBoxGPIOPin11.IsChecked.Value)
                    {
                        IsGetGPIOPin11 = true;
                        CheckBoxGPIOPin11.IsChecked = true;
                    }
                }
                else
                {
                    if (CheckBoxGPIOPin11.IsChecked.Value)
                    {
                        IsGetGPIOPin11 = true;
                        CheckBoxGPIOPin11.IsChecked = false;
                    }
                }
                if ((val & (byte)0x01) > 0)
                {
                    if (!CheckBoxGPIOPin14.IsChecked.Value)
                    {
                        IsGetGPIOPin14 = true;
                        CheckBoxGPIOPin14.IsChecked = true;
                    }
                }
                else
                {
                    if (CheckBoxGPIOPin14.IsChecked.Value)
                    {
                        IsGetGPIOPin14 = true;
                        CheckBoxGPIOPin14.IsChecked = false;
                    }
                }
            }
            else
            {
                this.LabelMessage.Text = (this.Culture.IetfLanguageTag == "en-US") ? "Set GPIO Pins error" : "設定GPIO Pins失敗";
            }
        }
        #endregion


        #region === Group Information & Show ===
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnButtonUpdateClick(object sender, RoutedEventArgs e) {
			this.PreProcess = PROC_READ_REGULATION;
			this.mLabelArea.Text = "";
			this.mLabelFrequncy.Text = "";
			this.mLabelFrequncyOffset.Text = "";
			this.mLabelPower.Text = "";
			this.ProcessEvent.Start();
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void OnListBoxMenuItemClick_Delete(object sender, RoutedEventArgs e) {
			if (this.ListBoxInfo.SelectedIndex == -1) return;
			this.ListBoxInfo.Items.Clear();
		}

        #endregion




        private void OnBorderTitleMouseLeftDown(object sender, MouseButtonEventArgs e) {
			this.DragMove();
		}


		private void OnCloseClick(object sender, RoutedEventArgs e) {
			this.Close();
		}


		private void DisplayText(string str, string data) {
			ListBoxItem itm = new ListBoxItem();
			if (str == "TX") {
				this.IsDateTimeStamp = true;
				itm.Foreground = Brushes.SeaGreen;
			}
			else
				itm.Foreground = Brushes.DarkRed;
			if (this.IsDateTimeStamp) {
				if (str == "RX") this.IsDateTimeStamp = false;
				if (data == null)
					itm.Content = string.Format("{0} [{1}] - ", DateTime.Now.ToString("yy/MM/dd H:mm:ss.fff"), str);
				else {
					if (str == "RX")
						itm.Content = string.Format("{0} [{1}] - \n{2}", DateTime.Now.ToString("yy/MM/dd H:mm:ss.fff"), str, ReaderService.Format.ShowCRLF(data));
					else
						itm.Content = string.Format("{0} [{1}] - {2}", DateTime.Now.ToString("yy/MM/dd H:mm:ss.fff"), str, ReaderService.Format.ShowCRLF(data));
				}
			}
			else {
				if (data == null)
					itm.Content = string.Format("[{0}] - ", str);
				else
					if (IsReceiveData)
						itm.Content = ReaderService.Format.ShowCRLF(data);
					else
						itm.Content = string.Format("{0}  -- {1}", ReaderService.Format.ShowCRLF(data), DateTime.Now.ToString("H:mm:ss.fff"));
			}

			if (this.ListBoxInfo.Items.Count > 1000)
				this.ListBoxInfo.Items.Clear();

			this.ListBoxInfo.Items.Add(itm);
			this.ListBoxInfo.ScrollIntoView(this.ListBoxInfo.Items[this.ListBoxInfo.Items.Count - 1]);
			itm = null;
		}


        /// <summary>
        /// 
        /// </summary>
        /// <param name="s"></param>
        /// <param name="b"></param>
		private void UIUnitControl(String s, Boolean b) {
			this.LabelMessage.Text = s;
			this.ButtonUpdate.IsEnabled = b;
            this.ButtonSetArea.IsEnabled = b;
            this.ButtonSetFrequency.IsEnabled = b;
			this.ButtonAdiust.IsEnabled = b;
			this.ButtonSetFrequencyPlus.IsEnabled = b;
			this.ButtonSetFrequencyMinus.IsEnabled = b;
			this.ButtonSetPower.IsEnabled = b;
			this.ButtonMeasureSetFrequency.IsEnabled = b;
			this.ComboBoxArea.IsEnabled = b;
			if (!this.IsRunning)
				this.ButtonMeasureRun.IsEnabled = b;
			this.ButtonSetFrequencyReset.IsEnabled = b;
            this.ButtonSetBuadRate.IsEnabled = b;
            this.ButtonGetGPIOConfiguration.IsEnabled = b;
            this.ButtonGetGPIOPort.IsEnabled = b;
            this.CheckBoxGPIOConfigur10.IsEnabled = b;
            this.CheckBoxGPIOConfigur11.IsEnabled = b;
            this.CheckBoxGPIOConfigur14.IsEnabled = b;
            this.CheckBoxGPIOPin10.IsEnabled = b;
            this.CheckBoxGPIOPin11.IsEnabled = b;
            this.CheckBoxGPIOPin14.IsEnabled = b;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
		private bool IsAlphabetic(String s) {
			Regex r = new Regex(@"^[0-9.]+$");
			return r.IsMatch(s);
		}


		private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e) {
			if (!IsAlphabetic(e.Text))
				e.Handled = true;
		}


		private void TextBox_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e) {
			if (e.Key == Key.Space)
				e.Handled = true;
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void DoRepeatWork(object sender, EventArgs e) {
			if (this.IsRunning) {
				if (!this.IsReceiveData) {
					this.IsReceiveData = true;
					DoSendWork(this._ReaderService.Command_U(), ReaderService.Module.CommandType.Normal);
				}
			}
			else {
				while (this.IsReceiveData) { Thread.Sleep(32); }
				this.RepeatEvent.Stop();
				UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Tag test is stop." : "已停止Tag測試", true);
			}
			
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="bs"></param>
        /// <param name="t"></param>
		private void DoSendWork(Byte[] bs, ReaderService.Module.CommandType t) {
			if (bs != null) {
				if (t == ReaderService.Module.CommandType.Normal)
					DisplayText("TX", ReaderService.Format.ShowCRLF(ReaderService.Format.BytesToString(bs)));			
				else
					DisplayText("TX", ReaderService.Format.BytesToHexString(bs));			
				this._ReaderService.Send(bs, t);
			}
		}


        /// <summary>
        /// 
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        private Byte[] DoReceiveWork(ReaderService.Module.CommandType t) {
			byte[] b = this._ReaderService.Receive();
			Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
				ListBoxItem itm = new ListBoxItem();
				itm.Foreground = Brushes.DarkRed;

				if (t == ReaderService.Module.CommandType.Normal)
					itm.Content = string.Format("{0} [RX] - {1}", DateTime.Now.ToString("yy/MM/dd H:mm:ss.fff"), ReaderService.Format.ShowCRLF(ReaderService.Format.BytesToString(b)));
				else
					itm.Content = string.Format("{0} [RX] - {1}", DateTime.Now.ToString("yy/MM/dd H:mm:ss.fff"), ReaderService.Format.BytesToHexString(b));
				this.ListBoxInfo.Items.Add(itm);
				this.ListBoxInfo.ScrollIntoView(this.ListBoxInfo.Items[this.ListBoxInfo.Items.Count - 1]);
			}));
			
			return b;
		}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void DoPreProcessWork(object sender, EventArgs e) {
			byte[] bs = null;
			string str0;
			switch (this.PreProcess) {
				case PROC_READ_REGULATION:
					UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Get frequency information." : "讀取頻率資訊..", false);
					DoSendWork(this._ReaderService.ReadRegulation(), ReaderService.Module.CommandType.Normal);
					this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);

                    if (this.ReceiveData == null) {
						UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
							"The Reader has no callback message, check and confirm the connecting status, please." : 
							"沒有任何回覆，請確認Reader是否連上", 
							false);
						this.ProcessEvent.Stop();
					}
					else {
						if (this.ReceiveData[1] == 0x4E) {
							switch (this.ReceiveData[3]) {
								case 0x31: this.mLabelArea.Text = "01: US 902~928"; IRegulation = 1; break;
								case 0x32: this.mLabelArea.Text = "02: TW 922~928"; IRegulation = 2; break;
								case 0x33: this.mLabelArea.Text = "03: CN 920~925"; IRegulation = 3; break;
								case 0x34: this.mLabelArea.Text = "04: CN2 840~845"; IRegulation = 4; break;
								case 0x35: this.mLabelArea.Text = "05: EU 865~868"; IRegulation = 5; break;
                                case 0x36: this.mLabelArea.Text = "06: JP 916~921"; IRegulation = 6; break;
                                case 0x37: this.mLabelArea.Text = "07: KR 917~921"; IRegulation = 7; break;
                                case 0x38: this.mLabelArea.Text = "08: VN 918~923"; IRegulation = 8; break;
                            }
							this.ComboBoxArea.SelectedIndex = IRegulation - 1;
                            ComboBoxSetAreaChanged(this.ComboBoxArea.SelectedIndex);
                            this.PreProcess = PROC_READ_MODE_AND_CHANNEL;
						}
						else {
							UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Error callback." : "錯誤回覆",  true);
							this.ProcessEvent.Stop();
						}
					}
					break;
				case PROC_READ_MODE_AND_CHANNEL:
					UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Get the regulation mode and channel." : "讀取頻率模式和頻道..", false);
					switch (this._Version) {
						case ReaderService.Module.Version.FI_R300A_C1:
						case ReaderService.Module.Version.FI_R300T_D1:
							DoSendWork(this._ReaderService.Command_AA("FF04008702"), ReaderService.Module.CommandType.AA);
							this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.AA);	
							break;
						case ReaderService.Module.Version.FI_R300A_C2:
                        case ReaderService.Module.Version.FI_R300A_C2C4:
                        case ReaderService.Module.Version.FI_R300A_C3:
                        case ReaderService.Module.Version.FI_R300T_D2:
                        case ReaderService.Module.Version.FI_R300T_D204:
                        case ReaderService.Module.Version.FI_R300S:
                        case ReaderService.Module.Version.FI_A300S:
							DoSendWork(this._ReaderService.ReadModeandChannel(), ReaderService.Module.CommandType.Normal);
							bs = DoReceiveWork(ReaderService.Module.CommandType.Normal);
							this.ReceiveData = ReaderService.Format.HexStringToBytes(ReaderService.Format.RemoveCRLF(ReaderService.Format.BytesToString(bs)));
							break;
					}
					if (this.ReceiveData[0] == 0xFF || this.ReceiveData[0] == 0x0) this.mLabelFrequncy.Text = "hopping";
					else {
						String s = null, m;
						Double j;
						Int32 i = (this.ReceiveData[1] > 0) ? this.ReceiveData[1] - 1 : this.ReceiveData[1];
						switch (this.IRegulation) {
							case 1:
								j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.US, i);
                                s = String.Format("{0}MHz", j.ToString("###.00"));
								break;
							case 2:
								j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.TW, i);
                                s = string.Format("{0}MHz", j.ToString("###.00"));
								break;
							case 3:
								j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.CN, i);
                                s = string.Format("{0}MHz", j.ToString("###.000"));
								break;
							case 4:
								j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.CN2, i);
                                s = string.Format("{0}MHz", j.ToString("###.000"));
								break;
							case 5:
								j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.EU, i);
                                s = string.Format("{0}MHz", j.ToString("###.00"));
								break;
                            case 6:
                                j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.JP, i);
                                s = string.Format("{0}MHz", j.ToString("###.00"));
                                break;
                            case 7:
                                j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.KR, i);
                                s = string.Format("{0}MHz", j.ToString("###.00"));
                                break;
                            case 8:
                                j = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.VN, i);
                                s = string.Format("{0}MHz", j.ToString("###.00"));
                                break;
                        }

						if (this.ReceiveData[0] == 0x01) {
							m = "Carry";
							BasebandCarryMode.IsChecked = true;
						}
						else {
							m = "RX";
							BasebandRXMode.IsChecked = true;
						}
						this.mLabelFrequncy.Text = string.Format("Fix mode, {0} Freq. = {1}", m, s);
                        this.ComboBoxMeasureFrequency.SelectedIndex = i;
                    }
						
					this.PreProcess = PROC_READ_FREQ_OFFSET;
					break;

				case PROC_READ_FREQ_OFFSET:
					UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Get the Reader frequency offset.." : "讀取Reader頻率Offset..", false);
					switch (this._Version) {
						case ReaderService.Module.Version.FI_R300A_C1:
						case ReaderService.Module.Version.FI_R300T_D1:
							DoSendWork(this._ReaderService.Command_AA("FF04008903"), ReaderService.Module.CommandType.AA);
							this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.AA);
							break;
						case ReaderService.Module.Version.FI_R300A_C2:
                        case ReaderService.Module.Version.FI_R300A_C2C4:
                        case ReaderService.Module.Version.FI_R300A_C3:
                        case ReaderService.Module.Version.FI_R300T_D2:
                        case ReaderService.Module.Version.FI_R300T_D204:
                        case ReaderService.Module.Version.FI_R300S:
                        case ReaderService.Module.Version.FI_A300S:
							DoSendWork(this._ReaderService.ReadFrequencyOffset(), ReaderService.Module.CommandType.Normal);
							bs = DoReceiveWork(ReaderService.Module.CommandType.Normal);
							this.ReceiveData = ReaderService.Format.HexStringToBytes(ReaderService.Format.RemoveCRLF(ReaderService.Format.BytesToString(bs)));
							break;
					}

					if (this.ReceiveData[0] > 0x01)
						this.mLabelFrequncyOffset.Text = "N/A";
					else {
						string strSymbol = (ReceiveData[0] == 0x00) ? "-" : "+";
						int ii = ((ReceiveData[1] << 8) & 0xFF00) + (ReceiveData[2] & 0xFF);
						double db = (double)ii * (double)30.5;
						mLabelFrequncyOffset.Text = string.Format("{0}{1}Hz", strSymbol, db.ToString());
						
					}	
					this.PreProcess = PROC_READ_POWER;
					break;

				case PROC_READ_POWER:
					UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Get the Reader power.." : "讀取Reader功率..", false);
					DoSendWork(this._ReaderService.ReadPower(), ReaderService.Module.CommandType.Normal);
					this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.Normal);
					if (ReceiveData[0] == 0xFF) 
						this.mLabelPower.Text = "N/A";
					else {
						if (ReceiveData[1] == 0x4E) {
							byte[] b = new byte[] { ReceiveData[2], ReceiveData[3] };
							string str = Encoding.ASCII.GetString(b);

							switch (this._Version) {
								case ReaderService.Module.Version.FI_R300T_D1:
								case ReaderService.Module.Version.FI_R300T_D2:
                                case ReaderService.Module.Version.FI_R300T_D204:
                               
                                    if (ReaderService.Format.HexStringToByte(str) >= 0x1B) {
										this.mLabelPower.Text = "25dBm";
										this.ComboboxPower.SelectedIndex = 0;
									}
									else {
										this.mLabelPower.Text = string.Format("{0}dBm", ReaderService.Format.HexStringToByte(str) - 2);
										this.ComboboxPower.SelectedIndex = 25 - (ReaderService.Format.HexStringToByte(str) - 2);
									}
									break;
								case ReaderService.Module.Version.FI_R300A_C1:
								case ReaderService.Module.Version.FI_R300A_C2:
                                case ReaderService.Module.Version.FI_R300A_C2C4:
                                case ReaderService.Module.Version.FI_R300A_C3:
                                    if (ReaderService.Format.HexStringToByte(str) >= 0x14) {
										this.mLabelPower.Text = "18dBm";
										this.ComboboxPower.SelectedIndex = 0;
									}
									else {
										this.mLabelPower.Text = string.Format("{0}dBm", ReaderService.Format.HexStringToByte(str) - 2);
										this.ComboboxPower.SelectedIndex = 18 - (ReaderService.Format.HexStringToByte(str) - 2);
									}
									break;
                                case ReaderService.Module.Version.FI_R300S:
                                case ReaderService.Module.Version.FI_A300S:
									if (ReaderService.Format.HexStringToByte(str) >= 0x1B) {
										this.mLabelPower.Text = "27dBm";
										this.ComboboxPower.SelectedIndex = 0;
									}
									else {
										this.mLabelPower.Text = string.Format("{0}dBm", ReaderService.Format.HexStringToByte(str));
										this.ComboboxPower.SelectedIndex = 27 - ReaderService.Format.HexStringToByte(str);
									}
									break;
								case ReaderService.Module.Version.FI_RXXXX:
									this.mLabelPower.Text = "N/A";
									break;
							}
						}
					}

                    //this.ProcessEvent.Stop();
                    //UIUnitControl("", true);
                    switch (this._Version)
                    {
                        case ReaderService.Module.Version.FI_RXXXX:
                        case ReaderService.Module.Version.FI_R300A_C1:
                        case ReaderService.Module.Version.FI_R300T_D1:
                        case ReaderService.Module.Version.FI_R300A_C2:
                        case ReaderService.Module.Version.FI_R300T_D2:
                        case ReaderService.Module.Version.FI_A300S:
                            this.ProcessEvent.Stop();
                            UIUnitControl("", true);
                            break;
                        case ReaderService.Module.Version.FI_R300A_C2C4:
                        case ReaderService.Module.Version.FI_R300T_D204:
                        case ReaderService.Module.Version.FI_R300A_C3:
                        case ReaderService.Module.Version.FI_R300S:
                            this.PreProcess = PROC_READ_GPIO_CONFIG;
                            break;
                    }
                    
                    break;

                case PROC_READ_GPIO_CONFIG:
                    UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Get the GPIO configuration.." : "讀取GPIO組態..", false);
                    OnButtonGetGPIOConfigurationClick(null, null);
                    this.PreProcess = PROC_READ_GPIO_PINS;
                    break;
                case PROC_READ_GPIO_PINS:
                    UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Get the GPIO pins.." : "讀取GPIO腳位數值..", false);
                    OnButtonGetGPIOPortClick(null, null);
                    this.ProcessEvent.Stop();
                    UIUnitControl("", true);
                    break;


                case PROC_READ_FREQ:
				case PROC_FREQ_SET_RESET:
					if (!IsReset) {
						str0 = null;
						double d0 = 0.0;
						switch (this._Version) {
							case ReaderService.Module.Version.FI_R300A_C1:
							case ReaderService.Module.Version.FI_R300T_D1:
								DoSendWork(this._ReaderService.Command_AA("FF04008903"), ReaderService.Module.CommandType.AA);
								this.ReceiveData = DoReceiveWork(ReaderService.Module.CommandType.AA);
								break;
							case ReaderService.Module.Version.FI_R300A_C2:
                            case ReaderService.Module.Version.FI_R300A_C2C4:
                            case ReaderService.Module.Version.FI_R300A_C3:
                            case ReaderService.Module.Version.FI_R300T_D2:
                            case ReaderService.Module.Version.FI_R300T_D204:
                            case ReaderService.Module.Version.FI_R300S:
                            case ReaderService.Module.Version.FI_A300S:
								DoSendWork(this._ReaderService.ReadFrequencyOffset(), ReaderService.Module.CommandType.Normal);
								bs = DoReceiveWork(ReaderService.Module.CommandType.Normal);
								this.ReceiveData = ReaderService.Format.HexStringToBytes(ReaderService.Format.RemoveCRLF(ReaderService.Format.BytesToString(bs)));
								break;
						}
						if (ReceiveData == null) {
							UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
								"The Reader has no callback message, check and confirm the connecting status, please." :
								"沒有任何回覆，確認Reader是否連上",
								false);
							this.ProcessEvent.Stop();
							return;
						}

						if (IsPlus | IsMinus | IsAdjust) {
							str0 = (ReceiveData[0] > 0x01) ? "{N/A}" : (ReceiveData[0] == 0x01) ? "+" : "-";
							if (ReceiveData[0] == 0xFF) {
								if (ReceiveData[1] == 0xFF) ReceiveData[1] = 0;
								if (ReceiveData[2] == 0xFF) ReceiveData[2] = 0;
							}
							d0 = ((ReceiveData[1] << 8) + ReceiveData[2]) * 30.5;
						}

						if (IsPlus) {
							int value = int.Parse(ComboboxStep.SelectedValue.ToString());
							int b = (int)((ReceiveData[1] << 8) + ReceiveData[2]);
							if (ReceiveData[0] > 0x0) { value += b; ReceiveData[0] = 0x1; }
							else {
								if (value > b) { value = value - b; ReceiveData[0] = 0x1; }
								else value = b - value;
							}
							ReceiveData[1] = (byte)(value >> 8);
							ReceiveData[2] = (byte)(value & 0xFF);

							string str1 = (ReceiveData[0] > 0) ? "+" : "-";
							double d1 = ((ReceiveData[1] << 8) + ReceiveData[2]) * 30.5;
							UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
								string.Format("Offset freq. {0}{1}Hz，adjust to {2}{3}Hz，and waiting for reboot.", str0, d0, str1, d1) :
								string.Format("目前offset頻率 {0}{1}Hz，調整為 {2}{3}Hz，並等候Reader重啟", str0, d0, str1, d1), false);
						}
						else if (IsMinus) {
							int value = int.Parse(ComboboxStep.SelectedValue.ToString());
							int b = (int)((ReceiveData[1] << 8) + ReceiveData[2]);
							if (ReceiveData[0] > 0x0) {
								if (value > b) { value = value - b; ReceiveData[0] = 0x0; }
								else value = b - value; }
							else { value += b; ReceiveData[0] = 0x0; }
							ReceiveData[1] = (byte)(value >> 8);
							ReceiveData[2] = (byte)(value & 0xFF);

							string str2 = (ReceiveData[0] > 0) ? "+" : "-";
							double d2 = ((ReceiveData[1] << 8) + ReceiveData[2]) * 30.5;
							UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
								string.Format("Offset freq. {0}{1}Hz，adjust to {2}{3}Hz，and waiting for reboot.", str0, d0, str2, d2) :
								string.Format("目前offset頻率 {0}{1}Hz，調整為 {2}{3}Hz，並等候Reader重啟", str0, d0, str2, d2), false);
						}
						else if (IsAdjust) {
							double fc, fm, fb, tf = 0;
							if (ReceiveData[0] == 0x00)//-
								fm = double.Parse(TextBoxMeasureFrequency.GetLineText(0)) * 1000000 + ((ReceiveData[1] << 8) + ReceiveData[2]) * 30.5;
							else
								fm = double.Parse(TextBoxMeasureFrequency.GetLineText(0)) * 1000000 - ((ReceiveData[1] << 8) + ReceiveData[2]) * 30.5;
							int idx = ComboBoxFrequency.SelectedIndex;
							switch (IRegulation) {
								case 1: tf = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.US, idx); break;
								case 2: tf = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.TW, idx); break;
								case 3: tf = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.CN, idx); break;
								case 4: tf = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.CN2, idx); break;
								case 5: tf = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.EU, idx); break;
                                case 6: tf = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.JP, idx); break;
                                case 7: tf = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.KR, idx); break;
                                case 8: tf = ReaderService.Module.RegulationFrequency(ReaderService.Module.Regulation.VN, idx); break;
                            }
							fc = tf * 1000000;
							fb = fc - fm;
							if (fb <= 0) {
								fb = fm - fc;
								IsSymbol = false;
							}
							else
								IsSymbol = true;

							ReceiveData[1] = (byte)(((int)(fb / 30.5) >> 8) & 0xFF);
							ReceiveData[2] = (byte)((int)(fb / 30.5) & 0xFF);
							//this.PreProcess = PROC_READ_FREQ_CALLBACK;
							//this.ProcessEvent.Start();
							UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
								string.Format("Adjust freq. to {0}Hz，and waiting for reboot.", fm) :
								string.Format("修正頻率至{0}, 並等待Reader重啟", fm),
								false);
						}
					}
					else {
						UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ? "Reset offset frequency, and waiting 2s for reboot." : "重置offset頻率，並等候Reader重啟(2s)", false);
                        //J000(reset) to set frequency (2017/4/18)
                        IsSetFrequency = true;
                        DoSendWork(this._ReaderService.Command_J("0", "00"), ReaderService.Module.CommandType.Normal);
                        DoReceiveWork(ReaderService.Module.CommandType.Normal);
                        ComboBoxMeasureFrequency.SelectedIndex = ReaderService.Module.RegulationChannel(IRegulation);
                    }
					this.PreProcess = PROC_SET_FREQ_H;
					break;

				case PROC_SET_FREQ_H:
					switch (this._Version) {
						case ReaderService.Module.Version.FI_R300A_C1:
						case ReaderService.Module.Version.FI_R300T_D1:
							str0 = string.Format("FF05008A{0}", (IsReset) ? "FF" : ReaderService.Format.ByteToHexString(ReceiveData[1]));
							DoSendWork(this._ReaderService.Command_AA(str0), ReaderService.Module.CommandType.AA);
							DoReceiveWork(ReaderService.Module.CommandType.AA);
							break;
						case ReaderService.Module.Version.FI_R300A_C2:
                        case ReaderService.Module.Version.FI_R300A_C2C4:
                        case ReaderService.Module.Version.FI_R300A_C3:
                        case ReaderService.Module.Version.FI_R300T_D2:
                        case ReaderService.Module.Version.FI_R300T_D204:
                        case ReaderService.Module.Version.FI_R300S:
                        case ReaderService.Module.Version.FI_A300S:
							str0 = (IsReset) ? "FF" : ReaderService.Format.ByteToHexString(ReceiveData[1]);
							DoSendWork(this._ReaderService.SetFrequencyAddrH(str0), ReaderService.Module.CommandType.Normal);
							DoReceiveWork(ReaderService.Module.CommandType.Normal);
							break;
					}			
					this.PreProcess = PROC_SET_FREQ_L;
					break;

				case PROC_SET_FREQ_L:
					switch (this._Version) {
						case ReaderService.Module.Version.FI_R300A_C1:
						case ReaderService.Module.Version.FI_R300T_D1:
							str0 = string.Format("FF05008B{0}", (IsReset) ? "FF" : ReaderService.Format.ByteToHexString(ReceiveData[2]));
							DoSendWork(this._ReaderService.Command_AA(str0), ReaderService.Module.CommandType.AA);
							DoReceiveWork(ReaderService.Module.CommandType.AA);
							break;
                        case ReaderService.Module.Version.FI_R300A_C2:
                        case ReaderService.Module.Version.FI_R300A_C2C4:
                        case ReaderService.Module.Version.FI_R300A_C3:
                        case ReaderService.Module.Version.FI_R300T_D2:
                        case ReaderService.Module.Version.FI_R300T_D204:
                        case ReaderService.Module.Version.FI_R300S:
                        case ReaderService.Module.Version.FI_A300S:
							str0 = (IsReset) ? "FF" : ReaderService.Format.ByteToHexString(ReceiveData[2]);
							DoSendWork(this._ReaderService.SetFrequencyAddrL(str0), ReaderService.Module.CommandType.Normal);
							DoReceiveWork(ReaderService.Module.CommandType.Normal);
							break;
					}			
					
					this.PreProcess = PROC_SET_FREQ;
					break;

				case PROC_SET_FREQ:
					switch (this._Version) {
						case ReaderService.Module.Version.FI_R300A_C1:
						case ReaderService.Module.Version.FI_R300T_D1:
							str0 = string.Format("FF060089{0}", (IsReset) ? "FF" :
															(IsPlus | IsMinus) ? ReaderService.Format.ByteToHexString(ReceiveData[0]) :
																IsSymbol ? "01" : "00");	
							this.IsPlus = false;
							this.IsMinus = false;
							this.IsReset = false;
							if (this.IsAdjust) {
								this.TextBoxMeasureFrequency.Text = String.Empty;
								this.IsAdjust = false;
							}
							DoSendWork(this._ReaderService.Command_AA(str0), ReaderService.Module.CommandType.AA);
							DoReceiveWork(ReaderService.Module.CommandType.AA);
							break;
                        case ReaderService.Module.Version.FI_R300A_C2:
                        case ReaderService.Module.Version.FI_R300A_C2C4:
                        case ReaderService.Module.Version.FI_R300A_C3:
                        case ReaderService.Module.Version.FI_R300T_D2:
                        case ReaderService.Module.Version.FI_R300T_D204:
                        case ReaderService.Module.Version.FI_R300S:
                        case ReaderService.Module.Version.FI_A300S:
							str0 = (IsReset) ? "FF" : (IsPlus | IsMinus) ? ReaderService.Format.ByteToHexString(ReceiveData[0]) : IsSymbol ? "01" : "00";
							this.IsPlus = false;
							this.IsMinus = false;
							this.IsReset = false;
							if (this.IsAdjust) {
								this.TextBoxMeasureFrequency.Text = String.Empty;
								this.IsAdjust = false;
							}
							DoSendWork(this._ReaderService.SetFrequency(str0), ReaderService.Module.CommandType.Normal);
							DoReceiveWork(ReaderService.Module.CommandType.Normal);
							break;
					}		
					this.PreProcess = PROC_SET_RESET;
					break;

				case PROC_SET_MEASURE_FREQ:
					Thread.Sleep(1000);
					OnButtonMeasureSetFrequencyClick(null, null);
					this.ProcessEvent.Stop();
					break;

				case PROC_SET_RESET:
					Thread.Sleep(2000);
					//DoReceiveWork(ReaderService.Module.CommandType.Normal);					
					UIUnitControl((this.Culture.IetfLanguageTag == "en-US") ?
						"The Reader has reboot." : 
						"Reader已重啟完成", 
						true);
					this.ProcessEvent.Stop();
					break;
			}
		}


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
		private void DoReceiveDataWork(object sender, ReaderService.CombineDataReceiveArgument e) {
			string s_crlf = e.Data;
			if (s_crlf.Equals(ReaderService.COMMANDU_END)) this.IsReceiveData = false;
			if (this.IsRunning) {	
				Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
					DisplayText("RX", s_crlf);
				}));
			}
			
		}
	}
}
