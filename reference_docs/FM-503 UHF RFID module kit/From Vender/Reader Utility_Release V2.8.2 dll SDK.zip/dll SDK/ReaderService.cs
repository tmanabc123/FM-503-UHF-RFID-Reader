﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.IO.Ports;
using System.Threading;
using System.Management;
using System.Windows.Threading;

namespace ReaderServiceDLL
{
	public class ReaderService
	{
		private SerialPort		mSerialPort;
		private Thread			mReceiveThread;
		private bool			mReceiveThreadFlag = false;
		private bool			mRaiseFlag = false;
		private byte[]			mReceiveBuffer;
		private StringBuilder	mBuilder;


		internal class ProcessConnection {

			public static ConnectionOptions ProcessConnectionOptions() {
				ConnectionOptions options = new ConnectionOptions();
				//Gets or sets the COM impersonation level to be used for operations in this connection.
				options.Impersonation = ImpersonationLevel.Impersonate;
				//Gets or sets the COM authentication level to be used for operations in this connection.
				options.Authentication = AuthenticationLevel.Default;
				//Gets or sets a value indicating whether user privileges need to be enabled for the connection operation.
				options.EnablePrivileges = true;
				return options;
			}

			public static ManagementScope ConnectionScope(string machineName, ConnectionOptions options, string path) {
				ManagementScope ms = new ManagementScope();
				ms.Path = new ManagementPath(@"\\" + machineName + path);
				ms.Options = options;
				//Connects this ManagementScope to the actual WMI scope.
				ms.Connect();
				return ms;
			}
		}

		public class ReaderSearch {
			public string mName { get; set; }
			public string mDescription { get; set; }

			public ReaderSearch() { }

			public static List<ReaderSearch> getInfo() {
				List<ReaderSearch> list = new List<ReaderSearch>();
				ConnectionOptions connectionOptions = ProcessConnection.ProcessConnectionOptions();
				ManagementScope managementScope = ProcessConnection.ConnectionScope(Environment.MachineName, connectionOptions, @"\root\CIMV2");
				ObjectQuery objectQuery = new ObjectQuery("SELECT * FROM Win32_PnPEntity WHERE ConfigManagerErrorCode = 0");
				ManagementObjectSearcher mos = new ManagementObjectSearcher(managementScope, objectQuery);


				using (mos) {
					string caption = null;
					ReaderSearch info = null;
					object obj;

					foreach (ManagementObject mo in mos.Get()) {
						if (mo != null) {
							info = new ReaderSearch();
							obj = mo["Caption"];
							if (obj != null) {
								caption = obj.ToString();
								//if (caption.Contains("FTDI"))
								if (caption.Contains("(COM") && (caption.Contains("Prolific") || caption.Contains("USB Serial Port")))
								{
									info.mName = caption.Substring(caption.LastIndexOf("(COM")).Replace("(", string.Empty).Replace(")", string.Empty);
									info.mDescription = caption;
									list.Add(info);
								}
							}
						}
					}
				}//using (mos)

				return list;
			}
		} 

		public class DataReceiveArgument : EventArgs {
			private byte[] data;
			public DataReceiveArgument(byte[] b) { this.data = b; }
			public int Length { get { return this.data.Length; } }
			public byte[] Data { get { return this.data; } }
		}

		public delegate void ReaderServiceDataHandler(object sender, DataReceiveArgument e);
		public event ReaderServiceDataHandler DataReceiveEvent;

		private void raiseDataReceive(byte[] b) {
			this.mRaiseFlag = true;
			if (DataReceiveEvent != null) {
				DataReceiveArgument e = new DataReceiveArgument(b);
				DataReceiveEvent(this, e);
			}
		}

		public ReaderService() {
			this.mSerialPort = new SerialPort();
			if (this.mBuilder == null) this.mBuilder = new StringBuilder();
		}

		public SerialPort serialPort() {
			return this.mSerialPort;
		}

		/* open serial port */
		public void openSerialPort(string port, int baudRate, Parity p, int bits, StopBits s) {
			if (!this.mSerialPort.IsOpen) {
				this.mSerialPort.PortName = port;
				this.mSerialPort.BaudRate = baudRate;
				this.mSerialPort.Parity = p;
				this.mSerialPort.DataBits = bits;
				this.mSerialPort.StopBits = s;
				this.mSerialPort.ReadTimeout = 800;
				this.mSerialPort.WriteTimeout = 500;
				this.mSerialPort.Open();

				this.mReceiveThread = new Thread(DoReceiveWork);
				this.mReceiveThread.IsBackground = true;
				this.mReceiveThread.Start();
			}
		}

		/* check serial port is open */
		public bool isOpen() { return this.mSerialPort.IsOpen; }

		/* send data */
		public void send(byte[] bs) {
			this.mRaiseFlag = false;
			if(isOpen())
				this.mSerialPort.Write(bs, 0, bs.Length); 
		}

		/* receive data and return, if none data that return null.*/
		public byte[] receive() {
			int i = 16;
			bool b = false;
			do {
				i--;
				if (i == 0) b = true;
				Thread.Sleep(64);
			} while (!this.mRaiseFlag && (i > 0));

			return (!b) ? this.mReceiveBuffer : null;
		}

		private void DoReceiveWork() {
			byte[] buffer = new byte[256];

			while (!this.mReceiveThreadFlag) {
				if (this.mSerialPort.BytesToRead > 0) {
					Thread.Sleep(64);

					int length = this.mSerialPort.Read(buffer, 0, buffer.Length);
					Array.Resize(ref buffer, length);
					this.mReceiveBuffer = buffer;
					Array.Resize(ref buffer, 256);
					this.raiseDataReceive(this.mReceiveBuffer);
				}
				Thread.Sleep(32);
			}
		}


		/* close serial port */
		public void closeSerialPort() {
			this.mReceiveThreadFlag = true;
			this.mReceiveThread.Join();
			if (this.mSerialPort.IsOpen) this.mSerialPort.Close();
		}


		private void clear() {
			if (this.mBuilder != null) this.mBuilder.Clear();
		}

		/* reader command parameter*/
		public ReaderService command_(byte paramCommand) {
			lock (this.mBuilder)
				this.mBuilder.Append(makesUpZero(byteToHexString(paramCommand), 2));
			return this;
		}
		public ReaderService command_(string paramCommand) {
			string s = BitConverter.ToString(Encoding.Default.GetBytes(paramCommand));
			s = s.Replace("-", "");
			lock (this.mBuilder) this.mBuilder.Append(s);
			return this;
		}
		public ReaderService command_(byte[] paramCommand) {
			lock (this.mBuilder)
				this.mBuilder.Append(bytesToHexString(paramCommand));
			return this;
		}
		public ReaderService bank_(string paramBank) {
			string s = BitConverter.ToString(Encoding.Default.GetBytes(paramBank));
			s = s.Replace("-", "");
			lock (this.mBuilder) this.mBuilder.Append(s);
			return this;
		}
		public ReaderService address_(string paramAddress) {
			string s = BitConverter.ToString(Encoding.Default.GetBytes(paramAddress));
			s = s.Replace("-", "");
			lock (this.mBuilder) this.mBuilder.Append(s);
			return this;
		}
		public ReaderService length_(string paramLength) {
			string s = BitConverter.ToString(Encoding.Default.GetBytes(paramLength));
			s = s.Replace("-", "");
			lock (this.mBuilder)
				this.mBuilder.Append(s);
			return this;
		}
		public ReaderService data_(byte paramData) {
			lock (this.mBuilder)
				this.mBuilder.Append(byteToHexString(paramData));
			return this;
		}
		public ReaderService data_(string paramData) {
			string s = BitConverter.ToString(Encoding.Default.GetBytes(paramData));
			s = s.Replace("-", "");
			lock (this.mBuilder) this.mBuilder.Append(s);
			return this;
		}
		public ReaderService password_(string paramPassword) {
			string s = BitConverter.ToString(Encoding.Default.GetBytes(makesUpZero(paramPassword,8)));
			s = s.Replace("-", "");
			lock (this.mBuilder) this.mBuilder.Append(s);
			return this;
		}
		public ReaderService recom_(byte paramRecom) {
			lock (this.mBuilder)
				this.mBuilder.Append(byteToHexString(paramRecom));
			return this;
		}
		public ReaderService mask_(string paramMask) {
			string s = BitConverter.ToString(Encoding.Default.GetBytes(makesUpZero(paramMask, 3)));
			s = s.Replace("-", "");
			lock (this.mBuilder)
				this.mBuilder.Append(s);
			return this;
		}
		public ReaderService action_(string paramAction) {
			string s = BitConverter.ToString(Encoding.Default.GetBytes(makesUpZero(paramAction, 3)));
			s = s.Replace("-", "");
			lock (this.mBuilder)
				this.mBuilder.Append(s);
			return this;
		}
		public ReaderService comma_() {
			lock (this.mBuilder)
				this.mBuilder.Append(BitConverter.ToString(Encoding.Default.GetBytes(",")));
			return this;
		}

		/*
		 * Commit your command back from this service.
		 * @return commit command.
		 * @throws Exception
		 */
		public byte[] commit()
		{
			if (this.mBuilder == null)
				throw new System.ArgumentException("data is null", "mBuilder");

			byte length = Convert.ToByte((this.mBuilder.Length + 2) / 2);
			this.mBuilder.Insert(0, makesUpZero(byteToHexString(0x0A), 2)).Append(makesUpZero(byteToHexString(0x0D), 2));

			string callback = this.mBuilder.ToString();
			clear();

			return hexStringToByteArray(callback);
		}


		public byte[] command_V() { return this.command_(0x56).commit(); }
		public byte[] command_S() { return this.command_(0x53).commit(); }
		public byte[] command_Q() { return this.command_(0x51).commit(); }
		public byte[] command_R(string paramBank, string paramAddress, string paramLength) {
			return this.command_(0x52)
						.bank_(paramBank).comma_()
						.address_(paramAddress).comma_()
						.length_(paramLength).commit(); 
		}
		public byte[] command_W(string paramBank, string paramAddress, string paramLength, string paramData)
		{
			return this.command_(0x57)
						.bank_(paramBank).comma_()
						.address_(paramAddress).comma_()
						.length_(paramLength).comma_()
						.data_(paramData).commit();
		}
		public byte[] command_K(string paramPassword, byte paramRecom) {
			return this.command_(0x4B)
						.password_(paramPassword).comma_()
						.recom_(paramRecom).commit();
		}
		public byte[] command_L(string paramMask, string paramAction) {
			return this.command_(0x4C)
						.mask_(paramMask).comma_()
						.action_(paramAction).commit();
		}
		public byte[] command_P(string paramPassword) {
			return this.command_(0x50).password_(paramPassword).commit();
		}
		public byte[] command_U() { return this.command_(0x55).commit(); }
		public byte[] command_T(string paramBank, string paramAddress, string paramLength, string paramData) {
			return this.command_(0x54)
						.bank_(paramBank).comma_()
						.address_(paramAddress).comma_()
						.length_(paramLength).comma_()
						.data_(paramData).commit();
		}
		public byte[] command_N(byte param, string paramData) {
			return this.command_(0x4E).command_(param).comma_()
						.data_(paramData).commit();
		}
		public byte[] command_J(byte param, string paramData)
		{
			return this.command_(0x4A).command_(param)
						.data_(paramData).commit();
		}
		public byte[] command_AA(string type, string command, string address, string data)
		{
			this.mBuilder.Append(makesUpZero(type, 2))
						.Append(makesUpZero(command, 2))
						.Append(makesUpZero(address, 4))
						.Append(makesUpZero(data, 2));

			byte length = Convert.ToByte((this.mBuilder.Length + 2) / 2);
			this.mBuilder.Insert(0, makesUpZero(byteToHexString(length), 2));

			byte crcData = crc8(hexStringToByteArray(this.mBuilder.ToString()));
			this.mBuilder.Append(makesUpZero(byteToHexString(crcData), 2));
			this.mBuilder.Insert(0, "AA");

			string callback = this.mBuilder.ToString();
			clear();

			return hexStringToByteArray(callback);
		}

		//Polynomial: x^8 + x^5 + x^4 + 1 (0x31)<br>
		//Initial value: 0x0
		//Residue: 0x0
		//The following is the equivalent functionality written in c#.  
		public byte crc8(byte[] paramBytes) {
			int crcInit = 0;
			int bitCount;

			for (int j = 0; j < paramBytes.Length; j++) {
				bitCount = 8;
				crcInit ^= paramBytes[j] & 0xFF;
				do {
					if ((crcInit & 0x80) != 0) crcInit = (crcInit << 1) ^ 0x31;
					else crcInit <<= 1;

					bitCount--;
				} while (bitCount > 0);
			}
			return (byte)crcInit;
		}



		/* fix length and zero-stuffing */
		public string makesUpZero(string str, int lenSize) {
			string zero = "00000000";
			string returnValue = zero;

			returnValue = zero + str;

			return returnValue.Substring(returnValue.Length - lenSize);

		}
		/* byte(s) to hex string */
		protected static char[] hexArray = "0123456789ABCDEF".ToCharArray();
		public string bytesToHexString(byte[] b) {
			char[] hexChars = new char[b.Length * 2];
			int v;
			for (int j = 0; j < b.Length; j++)
			{
				v = b[j] & 0xFF;
				hexChars[j * 2] = hexArray[v >> 4];
				hexChars[j * 2 + 1] = hexArray[v & 0x0F];
			}
			return new String(hexChars);
		}
		public string byteToHexString(byte b) {
			char[] hexChars = new char[2];
			int v = b & 0xFF;

			hexChars[0] = hexArray[v >> 4];
			hexChars[1] = hexArray[v & 0x0F];
			return new String(hexChars);
		}

		public string bytesToString(byte[] b) {
			return (b == null) ? "" : System.Text.Encoding.ASCII.GetString(b);
		}

		public string removeCRLF(string s) {
			// don't display \r or \n characters
			s = s.Replace("\r", string.Empty).Replace("\n", string.Empty);
			return s;
		}

		public string replaceCRLF(string s) {
			s = s.Replace("\r", "<CR>").Replace("\n", "<LF>");
			return s;
		}


		public byte[] hexStringToByteArray(string hex) {
			return Enumerable.Range(0, hex.Length)
						 .Where(x => x % 2 == 0)
						 .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
						 .ToArray();
		}

		public byte hexStringToByte(String s) {
			int len = s.Length;
			if (len == 2) {
				return (byte)((Convert.ToInt32(s[0].ToString(), 16) << 4)
										 + Convert.ToInt32(s[1].ToString(), 16));
			}
			else
				throw new InvalidOperationException();
		}

		public int hexStringToInt(String s) {
			return int.Parse(s, System.Globalization.NumberStyles.HexNumber);
		}


		public String stringToHexString(String str) {
			byte[] bytes = Encoding.UTF8.GetBytes(str.ToCharArray());
			return bytesToHexString(bytes);
		}
	}
}
